## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  prompt = TRUE,
  comment = NA
)

## ----eval=FALSE, echo=TRUE----------------------------------------------------
# library(limma)
# limmaRUsersGuide()

